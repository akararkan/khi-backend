package ak.dev.khi_backend.user.service;


import ak.dev.khi_backend.user.dto.ChangePasswordRequestDTO;
import ak.dev.khi_backend.user.dto.UpdateProfileRequestDTO;
import ak.dev.khi_backend.user.dto.UserResponseDTO;
import ak.dev.khi_backend.user.exceptions.UserAlreadyExistsException;
import ak.dev.khi_backend.user.model.User;
import ak.dev.khi_backend.user.repo.SessionRepository;
import ak.dev.khi_backend.user.repo.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.time.Duration;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

/**
 * Handles all self-service profile operations (GET me, update profile,
 * change password, upload image, delete account).
 *
 * Kept separate from UserService (which handles admin CRUD) to honour
 * single-responsibility and avoid the circular-dependency risk.
 */
@Service
@Transactional
@RequiredArgsConstructor
@Log4j2
public class UserProfileService {

    private static final long    MAX_FILE_SIZE   = 5 * 1024 * 1024; // 5 MB
    private static final List<String> ALLOWED_TYPES =
            Arrays.asList("image/jpeg", "image/png", "image/gif", "image/webp");
    private static final Duration PASSWORD_EXPIRY = Duration.ofDays(90);

    private final UserRepository    userRepository;
    private final SessionRepository sessionRepository;
    private final PasswordEncoder   passwordEncoder;

    @Value("${app.upload.dir:uploads/profile-images}")
    private String uploadDir;

    // ── helpers ──────────────────────────────────────────────────────────────

    private User requireUser(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() ->
                        new UsernameNotFoundException("User not found: " + username));
    }

    // ── GET me ───────────────────────────────────────────────────────────────

    public UserResponseDTO getByUsername(String username) {
        return toResponse(requireUser(username));
    }

    // ── Update profile ───────────────────────────────────────────────────────

    public UserResponseDTO updateProfile(String username, UpdateProfileRequestDTO dto) {
        User user = requireUser(username);

        // Username uniqueness check
        if (dto.getUsername() != null
                && !dto.getUsername().equals(user.getUsername())
                && userRepository.findByUsername(dto.getUsername()).isPresent()) {
            throw new UserAlreadyExistsException("ناوی بەکارهێنەر پێشتر بەکارهاتووە");
        }

        if (dto.getUsername() != null && !dto.getUsername().isBlank()) {
            user.setUsername(dto.getUsername());
        }
        if (dto.getName() != null) {
            user.setName(dto.getName());
        }

        user.setUpdatedAt(Instant.now());
        return toResponse(userRepository.save(user));
    }

    // ── Change password ──────────────────────────────────────────────────────

    public void changePassword(String username, ChangePasswordRequestDTO dto) {
        User user = requireUser(username);

        // OAuth2 users have a random password — disallow change via this endpoint
        if (!"local".equals(user.getProvider())) {
            throw new IllegalStateException(
                    "بەکارهێنەرانی OAuth2 ناتوانن وشەی نهێنییان بگۆڕن لە ئێرەدا");
        }

        if (!passwordEncoder.matches(dto.getCurrentPassword(), user.getPassword())) {
            throw new BadCredentialsException("وشەی نهێنیی ئێستا هەڵەیە");
        }

        if (dto.getNewPassword().length() < 6) {
            throw new IllegalArgumentException("وشەی نهێنیی نوێ دەبێت کەمترین ٦ پیت بێت");
        }

        user.setPassword(passwordEncoder.encode(dto.getNewPassword()));
        user.setPasswordExpiryDate(Instant.now().plus(PASSWORD_EXPIRY));
        user.setUpdatedAt(Instant.now());
        userRepository.save(user);
    }

    // ── Profile image ────────────────────────────────────────────────────────

    public UserResponseDTO uploadProfileImage(String username, MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("فایلەکە بەتاڵە");
        }

        User user = requireUser(username);
        deleteOldImage(user.getProfileImage());

        String path = storeImage(file);
        user.setProfileImage(path);
        user.setUpdatedAt(Instant.now());
        return toResponse(userRepository.save(user));
    }

    public UserResponseDTO removeProfileImage(String username) {
        User user = requireUser(username);
        deleteOldImage(user.getProfileImage());
        user.setProfileImage(null);
        user.setUpdatedAt(Instant.now());
        return toResponse(userRepository.save(user));
    }

    // ── Delete account ───────────────────────────────────────────────────────

    public void deleteAccount(String username) {
        User user = requireUser(username);
        deleteOldImage(user.getProfileImage());
        var sessions = sessionRepository.findByUser(user);
        if (sessions != null) sessionRepository.deleteAll(sessions);
        userRepository.delete(user);
        log.info("Account deleted for user: {}", username);
    }

    // ── File helpers ─────────────────────────────────────────────────────────

    private String storeImage(MultipartFile file) {
        try {
            if (file.getSize() > MAX_FILE_SIZE) {
                throw new IllegalArgumentException("قەبارەی وێنە دەبێت لە ٥ مێگابایت کەمتر بێت");
            }
            String ct = file.getContentType();
            if (ct == null || !ALLOWED_TYPES.contains(ct)) {
                throw new IllegalArgumentException(
                        "تەنها JPEG, PNG, GIF, WebP قبوڵ دەکرێت");
            }

            Path dir = Paths.get(uploadDir);
            if (!Files.exists(dir)) Files.createDirectories(dir);

            String original  = StringUtils.cleanPath(
                    file.getOriginalFilename() != null ? file.getOriginalFilename() : "image.jpg");
            String extension = original.contains(".")
                    ? original.substring(original.lastIndexOf('.')) : ".jpg";
            String filename  = UUID.randomUUID() + extension;

            Files.copy(file.getInputStream(), dir.resolve(filename),
                    StandardCopyOption.REPLACE_EXISTING);

            return uploadDir + "/" + filename;
        } catch (IOException ex) {
            throw new RuntimeException("بارکردنی فایل سەرکەوتوو نەبوو", ex);
        }
    }

    private void deleteOldImage(String path) {
        if (path == null || path.isBlank()) return;
        try {
            Files.deleteIfExists(Paths.get(path));
        } catch (IOException e) {
            log.warn("Could not delete old profile image: {}", path, e);
        }
    }

    // ── DTO mapper ───────────────────────────────────────────────────────────

    private UserResponseDTO toResponse(User u) {
        return UserResponseDTO.builder()
                .userId(u.getUserId())
                .name(u.getName())
                .username(u.getUsername())
                .email(u.getEmail())
                .role(u.getRole())
                .pincode(u.getPincode())
                .isActivated(u.getIsActivated())
                .profileImage(u.getProfileImage())
                .imageUrl(u.getImageUrl())
                .provider(u.getProvider())
                .createdAt(u.getCreatedAt())
                .updatedAt(u.getUpdatedAt())
                .passwordExpiryDate(u.getPasswordExpiryDate())
                .build();
    }
}