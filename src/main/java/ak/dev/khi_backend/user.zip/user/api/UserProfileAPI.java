package ak.dev.khi_backend.user.api;

import ak.dev.khi_backend.user.dto.UserResponseDTO;
import ak.dev.khi_backend.user.service.UserProfileService;
import ak.dev.khi_backend.user.dto.UpdateProfileRequestDTO;
import ak.dev.khi_backend.user.dto.ChangePasswordRequestDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

/**
 * Self-service profile endpoints for the currently authenticated user.
 * All routes are under /api/user  (singular — not /api/users)
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/user")
public class UserProfileAPI {

    private final UserProfileService userProfileService;

    // ── GET /api/user/me ─────────────────────────────────────────────────────
    @GetMapping("/me")
    public ResponseEntity<UserResponseDTO> getMe(
            @AuthenticationPrincipal UserDetails principal
    ) {
        return ResponseEntity.ok(userProfileService.getByUsername(principal.getUsername()));
    }

    // ── PUT /api/user/profile ─────────────────────────────────────────────────
    @PutMapping("/profile")
    public ResponseEntity<UserResponseDTO> updateProfile(
            @AuthenticationPrincipal UserDetails principal,
            @RequestBody UpdateProfileRequestDTO dto
    ) {
        return ResponseEntity.ok(
                userProfileService.updateProfile(principal.getUsername(), dto)
        );
    }

    // ── PUT /api/user/password ────────────────────────────────────────────────
    @PutMapping("/password")
    public ResponseEntity<Map<String, String>> changePassword(
            @AuthenticationPrincipal UserDetails principal,
            @RequestBody ChangePasswordRequestDTO dto
    ) {
        userProfileService.changePassword(principal.getUsername(), dto);
        return ResponseEntity.ok(Map.of("message", "Password updated successfully"));
    }

    // ── POST /api/user/profile-image ──────────────────────────────────────────
    @PostMapping(value = "/profile-image", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<UserResponseDTO> uploadProfileImage(
            @AuthenticationPrincipal UserDetails principal,
            @RequestPart("file") MultipartFile file
    ) {
        return ResponseEntity.ok(
                userProfileService.uploadProfileImage(principal.getUsername(), file)
        );
    }

    // ── DELETE /api/user/profile-image ────────────────────────────────────────
    @DeleteMapping("/profile-image")
    public ResponseEntity<UserResponseDTO> removeProfileImage(
            @AuthenticationPrincipal UserDetails principal
    ) {
        return ResponseEntity.ok(
                userProfileService.removeProfileImage(principal.getUsername())
        );
    }

    // ── DELETE /api/user/account ──────────────────────────────────────────────
    @DeleteMapping("/account")
    public ResponseEntity<Void> deleteAccount(
            @AuthenticationPrincipal UserDetails principal
    ) {
        userProfileService.deleteAccount(principal.getUsername());
        return ResponseEntity.noContent().build();
    }
}