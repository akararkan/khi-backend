package ak.dev.khi_backend.user.jwt;

import com.auth0.jwt.exceptions.TokenExpiredException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import ak.dev.khi_backend.user.service.TokenService;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;

import static ak.dev.khi_backend.user.consts.SecurityConstants.*;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;

@Component
@RequiredArgsConstructor
public class JWTAuthenticationFilter extends OncePerRequestFilter {

    private static final Logger logger = LoggerFactory.getLogger(JWTAuthenticationFilter.class);

    private final JwtTokenProvider jwtTokenProvider;
    @Qualifier("userService")
    private final UserDetailsService userDetailsService;
    private final TokenService tokenService;

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request,
                                    @NonNull HttpServletResponse response,
                                    @NonNull FilterChain filterChain) throws ServletException, IOException {

        try {
            // Allow OPTIONS requests to proceed (for CORS preflight)
            if (request.getMethod().equalsIgnoreCase(OPTIONS_HTTP_METHOD)) {
                response.setStatus(HttpStatus.OK.value());
                filterChain.doFilter(request, response);
                return;
            }

            String authorizationHeader = request.getHeader(AUTHORIZATION);

            if (!hasText(authorizationHeader) || !authorizationHeader.startsWith(TOKEN_PREFIX)) {
                filterChain.doFilter(request, response);
                return;
            }

            String token = authorizationHeader.substring(TOKEN_PREFIX.length());
            String username = null;

            try {
                // This will throw TokenExpiredException if expired
                username = jwtTokenProvider.getSubject(token);
            } catch (TokenExpiredException ex) {
                logger.warn("Token expired for request: {}", request.getRequestURI());
                sendErrorResponse(response, HttpStatus.UNAUTHORIZED, "TOKEN_EXPIRED", "Session expired, please login again");
                return;
            } catch (Exception ex) {
                logger.error("Invalid token", ex);
                sendErrorResponse(response, HttpStatus.FORBIDDEN, "INVALID_TOKEN", "Invalid token");
                return;
            }

            // Check if blacklisted (session invalidated/logout)
            if (jwtTokenProvider.isTokenBlacklisted(token)) {
                logger.warn("Token blacklisted for user: {}", username);
                sendErrorResponse(response, HttpStatus.UNAUTHORIZED, "TOKEN_REVOKED", "Session invalidated, please login again");
                return;
            }

            // ── FIX ──────────────────────────────────────────────────────────
            // Load a real UserDetails object so that @AuthenticationPrincipal
            // UserDetails resolves correctly in every controller.
            // Previously the principal was just a plain String (username), which
            // caused a NullPointerException whenever a controller injected
            // @AuthenticationPrincipal UserDetails principal.
            // ─────────────────────────────────────────────────────────────────
            if (hasText(username) && SecurityContextHolder.getContext().getAuthentication() == null) {
                UserDetails userDetails = userDetailsService.loadUserByUsername(username);
                List<GrantedAuthority> authorities = jwtTokenProvider.getAuthorities(token);
                Authentication authentication = jwtTokenProvider.getAuthentication(userDetails, authorities, request);
                SecurityContextHolder.getContext().setAuthentication(authentication);
                logger.debug("User '{}' authenticated successfully", username);
            }

        } catch (Exception ex) {
            logger.error("Unexpected error in JWT filter", ex);
            sendErrorResponse(response, HttpStatus.INTERNAL_SERVER_ERROR, "SERVER_ERROR", "Internal server error");
            return;
        }

        filterChain.doFilter(request, response);
    }

    private void sendErrorResponse(HttpServletResponse response, HttpStatus status, String error, String message) throws IOException {
        response.setStatus(status.value());
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.getWriter().write(String.format("{\"error\":\"%s\",\"message\":\"%s\"}", error, message));
    }

    private boolean hasText(String str) {
        return str != null && !str.trim().isEmpty();
    }
}