package ak.dev.khi_backend.khi_app.repository.project;

import ak.dev.khi_backend.khi_app.model.project.ProjectContent;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface ProjectContentRepository extends JpaRepository<ProjectContent, Long> {

    Optional<ProjectContent> findByNameIgnoreCase(String name);

    List<ProjectContent> findAllByNameIgnoreCaseIn(Collection<String> names);
}